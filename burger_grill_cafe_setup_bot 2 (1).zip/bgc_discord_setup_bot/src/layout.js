const roleNames = [
  "Customer",
  "Staff",
  "Moderator",
  "Administrator",
  "Corporate Intern",
  "Junior Corporate",
  "Senior Corporate",
  "Corporate Officer",
  "Chief Corporate Officer",
  "Executive Director",
  "Board of Administration",
  "Co-Founder",
  "Founder"
];

// Category access is granted to the listed roles. Public categories are visible
// to everyone. The bot does not grant Administrator permissions to any role.
const layout = [
  {
    name: "📌 INFORMATION",
    access: "public",
    channels: [
      ["👋・welcome", "text"], ["📢・announcements", "text"],
      ["📜・cafe-rules", "text"], ["📋・server-information", "text"],
      ["🤝・partnerships", "text"], ["🎭・roles", "text"],
      ["📅・events", "text"]
    ]
  },
  {
    name: "💬 COMMUNITY",
    access: "public",
    channels: [
      ["💬・general-chat", "text"], ["📸・media", "text"],
      ["🤖・bot-commands", "text"], ["😂・memes", "text"],
      ["🎮・game-chat", "text"], ["💡・suggestions", "text"],
      ["❓・questions", "text"]
    ]
  },
  {
    name: "🍔 CAFE",
    access: "public",
    channels: [
      ["🍟・cafe-updates", "text"], ["🧑‍🍳・menu", "text"],
      ["🏢・about-the-cafe", "text"], ["🕒・session-times", "text"],
      ["📣・session-announcements", "text"], ["🎉・cafe-events", "text"]
    ]
  },
  {
    name: "📝 APPLICATION CENTER",
    access: "public",
    channels: [
      ["📋・applications", "text"], ["🧑‍💼・staff-applications", "text"],
      ["🏢・corporate-applications", "text"], ["📩・application-results", "text"],
      ["❔・application-questions", "text"]
    ]
  },
  {
    name: "🎫 SUPPORT CENTER",
    access: "public",
    channels: [
      ["🎫・open-a-ticket", "text"], ["🚨・report-a-staff", "text"],
      ["📞・contact-management", "text"], ["⚖️・appeals", "text"],
      ["🤝・partnership-requests", "text"]
    ]
  },
  {
    name: "📢 STAFF INFORMATION",
    access: ["Staff", "Moderator", "Administrator", "Corporate Intern",
      "Junior Corporate", "Senior Corporate", "Corporate Officer",
      "Chief Corporate Officer", "Executive Director",
      "Board of Administration", "Co-Founder", "Founder"],
    channels: [
      ["📣・staff-announcements", "text"], ["📜・staff-guidelines", "text"],
      ["📅・staff-schedule", "text"], ["📊・staff-requirements", "text"],
      ["🎓・training-information", "text"]
    ]
  },
  {
    name: "🧑‍💼 MANAGEMENT",
    access: ["Administrator", "Corporate Intern", "Junior Corporate",
      "Senior Corporate", "Corporate Officer", "Chief Corporate Officer",
      "Executive Director", "Board of Administration", "Co-Founder", "Founder"],
    channels: [
      ["💬・management-chat", "text"], ["📢・management-announcements", "text"],
      ["📋・management-tasks", "text"], ["📈・weekly-requirements", "text"],
      ["⬆️・promotion-requests", "text"], ["⬇️・demotion-requests", "text"],
      ["📝・staff-reports", "text"], ["📊・activity-reports", "text"]
    ]
  },
  {
    name: "🏢 CORPORATE TEAM",
    access: ["Corporate Intern", "Junior Corporate", "Senior Corporate",
      "Corporate Officer", "Chief Corporate Officer", "Executive Director",
      "Board of Administration", "Co-Founder", "Founder"],
    channels: [
      ["💬・corporate-chat", "text"], ["📢・corporate-announcements", "text"],
      ["🎓・training-reports", "text"], ["👀・training-supervision", "text"],
      ["🍔・mass-shift-reports", "text"], ["⬆️・promotion-batches", "text"],
      ["📋・corporate-assignments", "text"]
    ]
  },
  {
    name: "👑 EXECUTIVE TEAM",
    access: ["Executive Director", "Board of Administration", "Co-Founder", "Founder"],
    channels: [
      ["💬・executive-chat", "text"], ["📢・executive-announcements", "text"],
      ["📋・executive-decisions", "text"], ["📊・executive-reports", "text"],
      ["⚖️・staff-investigations", "text"]
    ]
  },
  {
    name: "🔒 FOUNDERS",
    access: ["Co-Founder", "Founder"],
    channels: [
      ["👑・founder-chat", "text"], ["📋・founder-planning", "text"],
      ["🔐・server-management", "text"], ["📊・ownership-discussions", "text"],
      ["📁・important-documents", "text"]
    ]
  },
  {
    name: "🔊 VOICE CHANNELS",
    access: "public",
    channels: [
      ["🔊・General VC", "voice"], ["🍔・Cafe VC", "voice"],
      ["🧑‍💼・Staff VC", "voice"], ["🏢・Management VC", "voice"],
      ["👑・Executive VC", "voice"], ["🎓・Training VC", "voice"]
    ]
  }
];

module.exports = { roleNames, layout };
