require("dotenv").config();
const {
  Client, GatewayIntentBits, PermissionsBitField, ChannelType,
  SlashCommandBuilder, REST, Routes
} = require("discord.js");
const { roleNames, layout } = require("./layout");

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;
if (!DISCORD_TOKEN || !CLIENT_ID || !GUILD_ID) {
  console.error("Missing DISCORD_TOKEN, CLIENT_ID, or GUILD_ID in .env");
  process.exit(1);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const command = new SlashCommandBuilder()
  .setName("setup-server")
  .setDescription("Create the Burger & Grill Cafe categories, channels, and roles.")
  .addBooleanOption(option =>
    option.setName("confirm")
      .setDescription("Confirm that you want the bot to create the layout.")
      .setRequired(true)
  );

async function ensureRole(guild, name) {
  let role = guild.roles.cache.find(r => r.name === name);
  if (!role) {
    role = await guild.roles.create({
      name,
      // Roles are labels/access groups only; no Administrator permission is granted.
      permissions: [],
      reason: "Burger & Grill Cafe server setup"
    });
  }
  return role;
}

async function ensureCategory(guild, name, access, roles) {
  let category = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && c.name === name
  );

  const overwrites = [];
  if (access === "public") {
    overwrites.push({
      id: guild.roles.everyone.id,
      allow: [PermissionsBitField.Flags.ViewChannel]
    });
  } else {
    overwrites.push({
      id: guild.roles.everyone.id,
      deny: [PermissionsBitField.Flags.ViewChannel]
    });
    for (const roleName of access) {
      const role = roles.get(roleName);
      if (role) overwrites.push({
        id: role.id,
        allow: [
          PermissionsBitField.Flags.ViewChannel,
          PermissionsBitField.Flags.ReadMessageHistory,
          PermissionsBitField.Flags.SendMessages,
          PermissionsBitField.Flags.Connect,
          PermissionsBitField.Flags.Speak
        ]
      });
    }
  }

  if (!category) {
    category = await guild.channels.create({
      name,
      type: ChannelType.GuildCategory,
      permissionOverwrites: overwrites,
      reason: "Burger & Grill Cafe server setup"
    });
  } else {
    // Update category visibility while preserving the category itself.
    await category.permissionOverwrites.set(overwrites);
  }
  return category;
}

client.once("ready", () => {
  console.log(`Logged in as ${client.user.tag}`);
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand() || interaction.commandName !== "setup-server") return;

  if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) {
    return interaction.reply({
      content: "You need the **Manage Server** permission to run this setup.",
      ephemeral: true
    });
  }

  if (!interaction.options.getBoolean("confirm")) {
    return interaction.reply({ content: "Setup cancelled. Nothing was changed.", ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    const guild = interaction.guild;
    if (!guild) throw new Error("Run this command inside your Discord server.");

    // Create low-ranking roles first so higher roles can be positioned above them.
    const roles = new Map();
    for (const name of roleNames) roles.set(name, await ensureRole(guild, name));

    // Place the created roles in the requested hierarchy where Discord permits.
    // The bot's own highest role must be above these roles.
    const positions = roleNames.map((name, index) => ({
      role: roles.get(name).id,
      position: index + 1
    }));
    await guild.roles.setPositions(positions).catch(() => {
      console.warn("Could not reorder every role. Move the bot role higher and adjust roles manually.");
    });

    let madeCategories = 0;
    let madeChannels = 0;
    for (const section of layout) {
      const category = await ensureCategory(guild, section.name, section.access, roles);
      madeCategories++;

      for (const [name, kind] of section.channels) {
        const type = kind === "voice" ? ChannelType.GuildVoice : ChannelType.GuildText;
        const existing = guild.channels.cache.find(
          c => c.name === name && c.parentId === category.id && c.type === type
        );
        if (!existing) {
          await guild.channels.create({
            name,
            type,
            parent: category.id,
            reason: "Burger & Grill Cafe server setup"
          });
          madeChannels++;
        }
      }
    }

    await interaction.editReply(
      `🍔 **Burger & Grill Cafe setup complete!**\n` +
      `Categories checked: ${madeCategories}\n` +
      `New channels created: ${madeChannels}\n` +
      `Roles checked: ${roleNames.length}\n\n` +
      `No existing channels were deleted. Review role order and assign roles to your members.`
    );
  } catch (error) {
    console.error(error);
    await interaction.editReply(
      `Setup ran into a problem: ${String(error.message || error).slice(0, 500)}`
    );
  }
});

(async () => {
  const rest = new REST({ version: "10" }).setToken(DISCORD_TOKEN);
  await rest.put(
    Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
    { body: [command.toJSON()] }
  );
  await client.login(DISCORD_TOKEN);
})();
