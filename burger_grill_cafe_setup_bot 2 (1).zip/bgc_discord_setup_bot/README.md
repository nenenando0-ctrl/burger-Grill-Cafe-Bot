# Burger & Grill Cafe Discord Setup Bot

This bot creates the server layout discussed in ChatGPT: categories, text/voice channels, and role names.

## Before you start
- You need permission to manage the Discord server.
- Install Node.js 20 or newer.
- Create an application and bot in the Discord Developer Portal.
- Keep your bot token private. Never send it to anyone or paste it into public chats.

## 1. Create the bot
1. Open https://discord.com/developers/applications
2. Select **New Application** and name it `Burger & Grill Cafe Setup`.
3. Open **Bot** and choose **Reset Token** / **Copy Token**. Keep it secret.
4. Under **OAuth2 > General**, copy the **Application ID**.
5. Under **OAuth2 > URL Generator**, select scopes `bot` and `applications.commands`.
6. Select bot permissions:
   - Manage Channels
   - Manage Roles
   - View Channels
   - Send Messages
   - Read Message History
7. Open the generated invite link and add the bot to your server.
8. In **Server Settings > Roles**, move the bot's role ABOVE the roles it needs to create/manage.

Do not give the bot Administrator permission. Do not share your token.

## 2. Configure
1. Download and unzip this project.
2. Copy `.env.example` and rename the copy to `.env`.
3. Put your values in `.env`:
   - `DISCORD_TOKEN`: bot token
   - `CLIENT_ID`: application ID
   - `GUILD_ID`: your server ID (enable Developer Mode, right-click server icon, Copy Server ID)

## 3. Run
Open a terminal in the project folder and run:

```bash
npm install
npm run deploy
npm start
```

Keep the terminal running while you use the bot.

## 4. Build the server
In your Discord server, run:

`/setup-server confirm:true`

The bot checks for existing roles/categories/channels and creates missing ones. It does not delete existing channels.

## Important notes
- The bot creates role names but does not assign them to people.
- It does not give any role Administrator permissions.
- Discord only lets the bot manage roles below its own highest role. If role ordering fails, move the bot role higher and adjust the hierarchy manually.
- Public channels are visible to everyone. Private staff/management/corporate/executive/founder categories are restricted to the roles listed in `src/layout.js`.
- The bot is a starter project. Review the permissions and channel access before inviting members.
